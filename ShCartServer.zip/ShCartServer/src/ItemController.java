

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.ResponseWrapper;

import modelClass.Item;


@WebServlet("/ItemController")
public class ItemController extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
    public ItemController() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			Item item= new Item();
			item.setId(1);
			item.setName("iPhone x+");
			item.setDescription("white");
			item.setPrice(120000.00);
			item.setPath("");
			
			
			
			response.getWriter().print(item);
		} catch (Exception e) {
		e.printStackTrace();
		}
	}



}
